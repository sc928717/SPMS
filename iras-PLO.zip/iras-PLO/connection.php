<?php
    session_start();
    $con = mysqli_connect('localhost','root');
    mysqli_select_db($con, 'spm');
    $_SESSION['semester'] = "Autumn";
    $_SESSION['year'] = "2021";

?>