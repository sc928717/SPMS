<?php


$questionArr = $_POST['questionDescription'];
$coSelectorArr = array();
$_SESSION['issetCO'] = false;

if ($_SESSION['issetCO']) {
    $content = "content2";
    $contentLoader = "contentLoader2";
} else {
    $content = "content1";
    $contentLoader = "contentLoader1";
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Make Questions</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>

    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <link rel="stylesheet" href="facultyStyle.css">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">
        <a class="navbar-brand" href="#"> Preview Questions</a>


        <!-- <div class="dropDownWrapper">
            <select id="course_dropDown" class="form-select">
                <option selected disabled> <i>Course List </i></option>
                <option value="CSC101_1"> CSC101 - Section: 1</option>
                <option value="CSC203_4"> CSC203 - Section: 4</option>
                <option value="CSC203L_4"> CSC203L - Section: 4</option>
                <option value="CSC101L_1"> CSC101L - Section: 1</option>
            </select>
        </div> -->
        <p>&nbsp&nbsp&nbsp</p>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="data">
                <a href="dashboard_Faculty.php"><button type="button" class="btn btn-success but">Main Page</button></a>
                <a href="makeQuestions.php"><button type="button" class="btn btn-success">Make questions</button></a>
                <a href="../index.php"><button type="button" class="btn btn-success" disabled>CQI Reports</button></a>

            </div>

            <ul class="navbar-nav ml-auto">
                <div class="navbar-text ml-auto">
                    <p>Faculty UserName</p>
                </div>
                <div class="navbar-text ml-lg-3">
                    <a href="../../index.php" class="btn btn-primary text-white shadow">Sign out</a>
                </div>
            </ul>
        </div>
    </nav>


    <!-- this is preview -->
    <form action="#" id="contentLoader1div" class="content3" style="display: none;" method="POST">
        <!--<label style="align-items: center;">Available PLOs for the course: </label>-->
        <h5 style="text-align: center;" id="title">Question Paper Preview</h5>
        <!-- <p>This are the prevous course outcome for semester Summer 2020 <a href="#">Past Paper 1</a> <a href="#">Past Paper 2</a> <a href="#">Past Paper 3</a></p> -->
        <!-- <label>PLO selection for summer 2021</label>&nbsp&nbsp -->

        <div class="input_fields_wraps">

            <div class="row CLO_Div">
                <div class="col-md-11">

                    <?php
                    /*
                    for ($i = 0; $i < count($questionArr); $i++) {
                        echo ($i + 1) . ". " . $questionArr[$i] . " PLOs: ";
                        $coIndex = "CO" . (string)($i + 1);
                        array_push($coSelectorArr, $_POST[$coIndex]);
                        for ($j = 0; $j < count($_POST[$coIndex]); $j++)
                            echo $_POST[$coIndex][$j] . ",   ";
                        echo "<br>";
                    }
                    */
                    for ($y = 0; $y < count($questionArr); $y++) {
                        echo '<label for="course_description">
                                Question ' . ($y + 1) . ':<p id="CLO_current_number"></p></label>';
                        //echo '<textarea name="questionDescription[]" id="course_description" value ="" disabled>' . $questionArr[$y] . '</textarea>';
                        echo '<p name="questionDescription[]">' . $questionArr[$y] . '</p>';
                        //array_push($coSelectorArr, $_POST[$coIndex]);
                        for ($x = 1; $x <= 6; $x++) {
                            $check = "CO-" . strval($x);
                            $coIndex = "CO" . (string)($y + 1);
                            for ($j = 0; $j < count($_POST[$coIndex]); $j++) {
                                if (($_POST[$coIndex][$j]) == $check) {

                                    echo '&nbsp&nbsp&nbsp<input type="checkbox" id = "1' . $x . '"name="CO1[]" value ="CO-' . $x . '" checked disabled>
                                    <label for = "1' . $x . '">CO-' . $x . '</label>';
                                }
                                /*else{
                                echo '&nbsp&nbsp&nbsp<input type="checkbox" id = "1' . $x . '"name="CO1[]" value ="CO-' . $x . ' disabled">
                                    <label for = "1' . $x . '">CO-' . $x . '</label>';
                            }*/
                            }
                        }
                        echo "<br><br>";
                    }
                    ?>

                </div>
                <!-- <button id="closer" align="right" onclick="$(this).parents('.CLO_Div').remove()"></button> -->

            </div>
        </div>

        <div align="right">
            <!-- <a href="#" id="saveID" class="btn btn-primary text-white shadow">Submit</a> -->
            <input type="button" name="insert" id="contentLoader" class="btn btn-primary text-white shadow but1" value="Edit" />
            <input type="submit" name="insert" class="btn btn-primary text-white shadow" value="Submit" />
        </div>
    </form>


    <!-- this is edit -->
    <form action="previewQuestions.php" id="contentLoaderdiv" class="content" style="display: none;" method="POST">
        <!--<label style="align-items: center;">Available PLOs for the course: </label>-->
        <h5 style="text-align: center;" id="title">Edit Question Paper</h5>
        <p>This are the prevous course outcome for semester Summer 2020 <a href="#">Past Paper 1</a> <a href="#">Past Paper 2</a> <a href="#">Past Paper 3</a></p>
        <label>PLO selection for summer 2021</label>&nbsp&nbsp<table class="table table-bordered">
            <thead class="thead-light">
                <tr>
                    <th>Course Outome</th>
                    <th>Description</th>
                    <th>Mapped PLOs</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>CO -1</td>
                    <td>Doe</td>
                    <td>PLO - 1, PLO - 2, PLO - 3</td>
                </tr>
                <tr>
                    <td>CO - 2</td>
                    <td>Moe</td>
                    <td>PLO - 1, PLO - 4, PLO - 8</td>
                </tr>
                <tr>
                    <td>CO - 3</td>
                    <td>Dooley</td>
                    <td>PLO - 5, PLO - 7, PLO - 12</td>
                </tr>
            </tbody>
        </table>
        <div class="input_fields_wrap">
            <div class="repeater-heading" align="center">
                <button type="button" class="btn btn-primary add_field_button repeater-add-btn" onclick="document.getElementById('closer').remove()">Add a question</button>
            </div>
            <div class="row CLO_Div">
                <div class="col-md-11">
                    <label for="course_description">
                        Write the question description below in details. Note: The following exam question will be saved as Question 1<p id="CLO_current_number"></p>
                    </label>
                    <!-- <textarea name="questionDescription[]" id="course_description" ></textarea> -->

                    <?php

                    for ($y = 0; $y < count($questionArr); $y++) {
                        echo '<label for="course_description">
                                Question ' . ($y + 1) . ':<p id="CLO_current_number"></p></label>';
                        //echo '<textarea name="questionDescription[]" id="course_description" value ="" disabled>' . $questionArr[$y] . '</textarea>';
                        echo '<textarea id="course_description" name="questionDescription[]" >' . $questionArr[$y] . '</textarea>';
                        //array_push($coSelectorArr, $_POST[$coIndex]);
                        for ($x = 1; $x <= 6; $x++) {
                            $check = "CO-" . strval($x);
                            $coIndex = "CO" . (string)($y + 1);
                            $isInsideLoop = false;
                            for ($j = 0; $j < count($_POST[$coIndex]); $j++) {
                                if (($_POST[$coIndex][$j]) == $check) {
                                    $isInsideLoop = true;
                                    echo '&nbsp&nbsp&nbsp<input type="checkbox" id = "' . $y . $x . '"name="CO'.($y + 1).'[]" value ="CO-' . $x . '" checked >
                                    <label for = "' . $y . $x . '">CO-' . $x . '</label>';
                                } 
                            }
                            if (!$isInsideLoop) {
                                echo '&nbsp&nbsp&nbsp<input type="checkbox" id = "' . $y . $x . '"name="CO'.($y + 1).'[]" value ="CO-' . $x . '">
                                        <label for = "' . $y . $x . '">CO-' . $x . '</label>';
                            }
                        }
                        echo "<br><br>";
                    }
                    ?>

                </div>
                <!-- <button id="closer" align="right" onclick="$(this).parents('.CLO_Div').remove()"></button> -->

            </div>
        </div>

        <div align="right">
            <!-- <a href="#" id="saveID" class="btn btn-primary text-white shadow">Submit</a> -->
            <input type="submit" name="insert" class="btn btn-primary text-white shadow but2" id="contentLoader1" value="Preview" />
            <!-- <input type="submit" name="insert" class="btn btn-primary text-white shadow" value="Submit" /> -->
        </div>
    </form>



    <form action="previewQuestions.php" id="contentLoader1div" class="content1" style="display: block;" method="POST">
        <!--<label style="align-items: center;">Available PLOs for the course: </label>-->
        <h5 style="text-align: center;" id="title">Exam</h5>
        <p>This are the prevous course outcome for semester Summer 2020 <a href="#">Past Paper 1</a> <a href="#">Past Paper 2</a> <a href="#">Past Paper 3</a></p>
        <label>PLO selection for summer 2021</label>&nbsp&nbsp<table class="table table-bordered">
            <thead class="thead-light">
                <tr>
                    <th>Course Outome</th>
                    <th>Description</th>
                    <th>Mapped PLOs</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>CO -1</td>
                    <td>Doe</td>
                    <td>PLO - 1, PLO - 2, PLO - 3</td>
                </tr>
                <tr>
                    <td>CO - 2</td>
                    <td>Moe</td>
                    <td>PLO - 1, PLO - 4, PLO - 8</td>
                </tr>
                <tr>
                    <td>CO - 3</td>
                    <td>Dooley</td>
                    <td>PLO - 5, PLO - 7, PLO - 12</td>
                </tr>
            </tbody>
        </table>
        <div class="input_fields_wrap">
            <div class="repeater-heading" align="center">
                <button type="button" class="btn btn-primary add_field_button repeater-add-btn" onclick="document.getElementById('closer').remove()">Add a question</button>
            </div>
            <div class="row CLO_Div">
                <div class="col-md-11">
                    <label for="course_description">
                        Write the question description below in details. Note: The following exam question will be saved as Question 1<p id="CLO_current_number"></p>
                    </label>
                    <textarea name="questionDescription[]" id="course_description" required></textarea>
                    <?php
                    for ($x = 1; $x <= 6; $x++) {
                        echo '&nbsp&nbsp&nbsp<input type="checkbox" id = "1' . $x . '"name="CO1[]" value ="CO-' . $x . '">
                                    <label for = "1' . $x . '">CO-' . $x . '</label>';
                    }
                    ?>

                </div>
                <!-- <button id="closer" align="right" onclick="$(this).parents('.CLO_Div').remove()"></button> -->

            </div>
        </div>

        <div align="right">
            <!-- <a href="#" id="saveID" class="btn btn-primary text-white shadow">Submit</a> -->
            <input type="submit"  class="btn btn-primary text-white shadow" value="Preview" />
        </div>
    </form>
</body>
<script>
    $(document).ready(function() {
            var x = 2; //initlal text box count
            var max_fields = 11; //maximum input boxes allowed
            var wrapper = $(".input_fields_wrap"); //Fields wrapper
            var add_button = $(".add_field_button"); //Add button ID


            var b = '"><div class="col-md-11"><label for="course_description">Write the course description below in details. Note: The following CO will be saved as Question ';
            var c = '<p id="CLO_current_number"></p></label><textarea name="questionDescription[]" id="course_description" required></textarea>';
            var d = '</div><button class = "remove_field" align="right" id="closer"></button></div>';


            $(add_button).click(function(e) { //on add input button click
                e.preventDefault();

                if (x <= max_fields) { //max input box allowed

                    //text box increment

                    var PLOArr = []

                    for (var i = 1; i <= 6; i++) {

                        //PLOArr.push('&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="checkbox" id = "' + x + i + '"name = "PLO[]">');
                        PLOArr.push('&nbsp&nbsp<input type="checkbox" id = "' + x + i + '"name = "CO' + x + '[]" value = "CO-' + i + '">');
                        PLOArr.push('<label for = "' + x + i + '">&nbspCO-' + i + '</label>');

                    }

                    var a = '<div class="row CLO_Div" id = "list' + x;

                    $(wrapper).append(a + b + x + c + PLOArr.join("") + d);
                    //$(wrapper).append(x);

                    x++;
                }
            });


            $(wrapper).on("click", ".remove_field", function(e) { //user click on remove text
                e.preventDefault();

                if (x > 3) {
                    var newItem = document.createElement('BUTTON');
                    newItem.id = "closer";
                    newItem.className = "remove_field";


                    //var newX = x - 2;
                    str = "list" + (x - 2).toString();
                    var list = document.getElementById(str);

                    list.insertBefore(newItem, list.childNodes[1]);
                }

                $(this).parent('div').remove();


                if (x >= 2) {
                    x--;
                } else {
                    x = 1;
                }
            })
        });

    // load edit, turn off preview
    $(function() {
        $(".but1").on("click", function(e) {
            e.preventDefault();
            //$(".contents").hide();
            $("#" + this.id + "div").fadeIn(700);
            trigger("contentLoader1div");
        });
    });
    function trigger(val) {
        var id = document.getElementById(val);
        if (id.style.display === "none") {
            id.style.display = "block";
        } else {
            id.style.display = "none";
        }
    }
    // load preview, turn off edit
    /*$(function() {
        $(".but2").on("click", function(e) {
            //e.preventDefault();
            //$(".contents1").hide();
            //$("#" + this.id + "div").fadeIn(700);
            //trigger("contentLoaderdiv");
        });
    });*/

    

    
</script>

</html>