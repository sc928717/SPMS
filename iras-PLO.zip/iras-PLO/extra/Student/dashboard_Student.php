<?php
session_start();


$One = "One";
$Two = "Two";
$Three = "Three";
$Four = "Four";
$Five = "Five";

$isExam = false;
//$isExam = true;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IRAS-PLO</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <!-- <link rel="stylesheet" href="../../css/bootstrap.min.css"> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="studentStyle.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>


    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <script src="../../scripts/jquery.min.js"></script>
    <script src="../../scripts/Chart.js"></script>


</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">
        <a class="navbar-brand" href="#">Home</a>


        <!-- <div class="dropDownWrapper">
            <select id="course_dropDown" class="form-select">
                <option selected disabled> <i>Course List </i></option>
                <option value="CSC101_1"> CSC101 - Section: 1</option>
                <option value="CSC203_4"> CSC203 - Section: 4</option>
                <option value="CSC203L_4"> CSC203L - Section: 4</option>
                <option value="CSC101L_1"> CSC101L - Section: 1</option>
            </select>
        </div> -->
        <p>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</p>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="datas">

                <a href="loadPastExams.php"><button type="button" class="btn btn-success but" id="contentLoader">Load Past Exams</button></a>&nbsp
                <a href="upComingExams.php"><button type="button" class="btn btn-success" disabled>Up-coming Exams</button></a>&nbsp

            </div>

            <ul class="navbar-nav ml-auto">
                <div class="navbar-text ml-lg-3">
                    <a href="../../index.php" class="btn btn-primary text-white shadow">Sign out</a>
                </div>
            </ul>
        </div>
    </nav>

    <br>




    <!-- <a href="" style = "text-decoration: none;">
        <div class="upcomingExamDiv">

            <p>Upcoming Exams:</p>
            <p>Exam type: Mid Term</p>
            <p>Course ID: CSC101</p>
            <p>Section: 1</p>
            <p>Syllabus: Varialbes, Loops and Functions</p>
            <p>Exam Time: 11.00 am | 25-April-2021</p>

        </div>
    </a> -->


    <div class="wrapper">

        <?php
        $questionID = 100;
        for ($i = 0; $i < 5; $i++) {
            echo "<form  method=\"POST\" action=\"giveExam.php\">
        <input type=\"hidden\" name=\"quesID\" value = " . $questionID + ($i + 1) . ">
        <a href = \"#\" onclick=\"document.forms[" . $i . "].submit();return false;\" style = \"text-decoration: none;\">
        <div class=\"loadExam\">
        <p>Upcoming Exams: Random</p>
        <p>Exam type: Mid Term</p>
        <p>Course ID: CSC101</p>
        <p>Section: 1</p>
        <p>Syllabus: Varialbes, Loops and Functions</p>
        <p>Exam Time: 11.00 am | 25-April-2021</p>

</div>
</a>
</form>";
        }

        ?>
    </div>




    <div style="background-color: whitesmoke;">
        <canvas id="myChart" style="width: 20vw;"></canvas>
    </div>

    <div id="contentLoaderdiv" class="content" style="position: relative;">
        <p><strong><i>Marks of all terms that are taken for all the registered courses for this semester:</i></strong></p>
        <table class="table table-bordered">
            <thead class="thead-light">
                <tr>
                    <th>Course ID</th>
                    <th>Section</th>
                    <th>Quizes</th>
                    <th>Mid Term</th>
                    <th>Final Term</th>
                    <th>Project</th>

                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>CSC 101</td>
                    <td>1</td>
                    <td>
                        <p>Quiz - 1: 20/20 </p>
                        <p>Quiz - 2: 15/20</p>
                    </td>
                    <td>80/100</td>
                    <td>95/100</td>
                    <td>70/100</td>
                </tr>

                <tr>
                    <td>CSC203</td>
                    <td>3</td>
                    <td>
                        <p>Quiz - 1: 20/20 </p>
                        <p>Quiz - 2: 15/20</p>
                    </td>
                    <td>80/100</td>
                    <td>95/100</td>
                    <td>No project</td>
                </tr>
                <tr>
                    <td>MAT301</td>
                    <td>2</td>
                    <td>
                        <p>Quiz - 1: 20/20 </p>
                        <p>Quiz - 2: 15/20</p>
                    </td>
                    <td>80/100</td>
                    <td>95/100</td>
                    <td>No project</td>
                </tr>
            </tbody>
        </table>
    </div>






    <script>
        var asd = "<?php echo $isExam; ?>";

        /*
        if (asd) {
            $(".upcomingExamDiv").hide();
            var id = document.getElementById("myChart");
            id.style.margin = "auto";
        }*/


        /*var flag = true;

        $(function() {
            $(".but").on("click", function(e) {
                e.preventDefault();
                if (flag) {
                    trigger("myChart");
                    $("#" + this.id + "div").fadeIn(700);
                    flag = false;
                } else {
                    flag = true;
                    trigger("contentLoaderdiv");
                    trigger("myChart");
                    $("myChart").fadeIn(700);
                }
            });
        });*/


        function trigger(val) {
            var id = document.getElementById(val);
            if (id.style.display === "none") {
                id.style.display = "block";
            } else {
                id.style.display = "none";
            }
        }

        var obj = ["Autumn 2020", "Summer2020", "Spring 2020", "Autumn 2021"];
        var obj2 = ["10", "11", "20", "45"];


        function BuildChart2(labels, values, chartTitle) {
            var ctx = document.getElementById("myChart").getContext('2d');
            var myChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels, // Our labels
                        datasets: [{
                            label: chartTitle, // Name the series
                            data: values, // Our values
                            fill: false,
                            backgroundColor: [ // Specify custom colors
                                'rgb(26, 46, 228)'
                            ],
                            borderColor: [ // Add custom color borders
                                'rgb(26, 46, 228)'
                            ],
                            borderWidth: 1 // Specify bar border width
                        }]
                    },
                    options: {
                        responsive: true, // Instruct chart js to respond nicely.
                        maintainAspectRatio: false, // Add to prevent default behavior of full-width/height 
                            scales: {
                                
                                xAxes: [{
                                    scaleLabel: {
                                        display: true,
                                        labelString: 'Semesters',

                                    }
                                }],

                                yAxes: [{
                                    ticks: {
                                        beginAtZero: true
                                    },
                                    scaleLabel: {
                                        display: true,
                                        labelString: 'PLO Points'
                                    }
                                }]
                            }

                        }
                    });
                return myChart;
            }
            var chart2 = BuildChart2(obj, obj2, "Semester wise performance base on PLO achievement");
    </script>

    <!-- <script src="../../scripts/graph.Loader.js"></script> -->
</body>

</html>