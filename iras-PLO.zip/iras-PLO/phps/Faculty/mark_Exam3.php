<?php

include '../../connection.php';
$sem = $_SESSION['semester'];
$y = $_SESSION['year'];
$id = $_SESSION['id']; // faculty id
$arr =  $_SESSION['array'];
if (isset($_POST['course'])) {
    $c = $_POST['course'];
} else {
    if (isset($arr[4])) {
        $c = $arr[4];
    } else {
        $c = $_SESSION['course'];
    }
}
// there is course id in $c
$_SESSION['course'] = $c;

$studentID = isset($_POST['student']) ? $_POST['student'] : null;
$examID = isset($_POST['examID']) ? $_POST['examID'] : null;
$_SESSION['exam'] = $examID;


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Panel</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <!-- <link rel="stylesheet" href="../../css/bootstrap.min.css"> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="facultyStyle.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>


    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <script src="../../scripts/repeater.js"></script>


</head>

<style>
    .tableStyle {
        background-color: white;
        height: auto;
        display: block;
        margin: 3vh;
        padding: 2%;
        border: 5px solid #746cc0;
    }
</style>

<body>

    <h3 align="center">Student ID : &nbsp &nbsp <?php echo $studentID?></h3> <br> <br>
    <!-- <button onclick="counterIncrement()">This is for test</button> -->

    <form action="updateMarking.php" class="tableStyle" method="POST">
        <h5 style="text-align: center;">Load Necessary Information about the exam and the following course</h5>
        <h5 style="text-align: center; color: blue;">Summer 2021</h5>
        <p></p>
        <input type="hidden" name="examID" value="<?php echo $examID;?>">

        <?php

        $q = "SELECT DISTINCT e.evaluationID as eva, q.quesID AS ques, q.details AS question, e.studentAns as answer, q.mark as mark FROM student AS s, 
            assessment AS a, question AS q, evaluation AS e WHERE e.quesID=q.quesID AND q.assessmentID = a.assessmentID 
            AND  e.obatinMarks = '-9999' AND a.enrollmentID = '$c' AND a.nameOfAss = '$examID' AND e.studentID = s.studentID AND e.studentID = '$studentID'";
        $query = mysqli_query($con, $q);
        $i = 0;
        while($t = mysqli_fetch_assoc($query)){
            echo "<div style = \"background-color: whitesmoke;\"><p><b>Question " . ($i + 1) . ": </b></p>
            <input type=\"hidden\" name = \"student\" value = " . $studentID . ">
            <input type=\"hidden\" name = \"ques[]\" value = " . $t['ques'] . ">
            <input type=\"hidden\" name = \"eva[]\" value = " . $t['eva'] . ">
            <p>".$t['question']."</p>
            <p>".$t['answer']."</p>
            <input type=\"number\" step=\"0.01\" min=\"0\" max=".$t['mark']." name = \"marks[]\" placeholder=\"Marks\" required><label> &nbsp Out of ".$t['mark']."</label></div>";
            $i++;
        }
        ?>
        <div align="center">
            <input type="submit" class="btn btn-primary text-white shadow" value="Submit Marks">
            <a href="../Faculty/facultyCourseInformation.php"><button type="button" class="btn btn-primary text-white shadow">Cancel</button></a>
        </div>
    </form>







    <!-- <script src="../../scripts/jquery.min.js"></script> -->
    <script>
        function startResigtration() {
            document.getElementById("statusID").value = "true";
        }
    </script>
    <!-- <script src="../../scripts/graph.Loader.js"></script> -->
</body>

</html>