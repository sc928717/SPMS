<?php
include '../../connection.php';
$sem = $_SESSION['semester'];
$y = $_SESSION['year'];
$arr =  $_SESSION['array'];
$co1 = $_POST['name1'];
$co2 = $_POST['name2'];
$co3 = $_POST['name3'];
$co4 = $_POST['name4'];
$course = $_POST['enroll'];
echo $course;
$c1 = "1_$course";
$c2 = "2_"."$course";
$c3 = "3_"."$course";
$c4 = "4_"."$course";
$c = substr($course, 3,1);
$insert = "INSERT INTO co (coID, description,courseLevel,enrollmentID) VALUES ('$c1', '$co1', '$c', '$course')";
mysqli_query($con, $insert);
$insert = "INSERT INTO co (coID, description,courseLevel,enrollmentID) VALUES ('$c2', '$co2', '$c', '$course')";
mysqli_query($con, $insert);
$insert = "INSERT INTO co (coID, description,courseLevel,enrollmentID) VALUES ('$c3', '$co3', '$c', '$course')";
mysqli_query($con, $insert);
$insert = "INSERT INTO co (coID, description,courseLevel,enrollmentID) VALUES ('$c4', '$co4', '$c', '$course')";
mysqli_query($con, $insert);

$insert = "INSERT INTO plocomapping (ploID, coID) VALUES ('$arr[0]', '$c1')";
mysqli_query($con, $insert);
$insert = "INSERT INTO plocomapping (ploID, coID) VALUES ('$arr[1]', '$c2')";
mysqli_query($con, $insert);
$insert = "INSERT INTO plocomapping (ploID, coID) VALUES ('$arr[2]', '$c3')";
mysqli_query($con, $insert);
$insert = "INSERT INTO plocomapping (ploID, coID) VALUES ('$arr[3]', '$c4')";
mysqli_query($con, $insert);

?>

<script>
        alert("Successfully Done....!!!");
        window.location = 'facultyCourseInformation.php';
    </script>