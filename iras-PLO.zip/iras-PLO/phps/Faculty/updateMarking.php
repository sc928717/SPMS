<?php

include '../../connection.php';
$sem = $_SESSION['semester'];
$y = $_SESSION['year'];
$id = $_SESSION['id']; // faculty id
$arr =  $_SESSION['array'];
if (isset($_POST['course'])) {
    $c = $_POST['course'];
} else {
    if (isset($arr[4])) {
        $c = $arr[4];
    } else {
        $c = $_SESSION['course'];
    }
}
// there is course id in $c
$_SESSION['course'] = $c;

$studentID = isset($_POST['student']) ? $_POST['student'] : null;
$ques = isset($_POST['ques']) ? $_POST['ques'] : null;
$marks = isset($_POST['marks']) ? $_POST['marks'] : null;
$eva = isset($_POST['eva']) ? $_POST['eva'] : null;
$y =0;
while($y<count($ques)){
    echo $id." ".$studentID." ".$ques[$y]." ".$marks[$y]." ".$eva[$y]."<br>";
    
    $q = "UPDATE evaluation
            SET obatinMarks = '$marks[$y]'
            WHERE evaluationID = '$eva[$y]'";
    mysqli_query($con, $q);
    $q = "INSERT INTO evaluation_faculty (evaluationID, facultyID) VALUES ('$eva[$y]', '$id')";
    mysqli_query($con, $q);
    $y++;
}
?>
<script>
    alert("Successfully Done....!!!");
    window.location = 'mark_Exam2.php';
</script>