<?php
    include '../../connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Enrollment Graph </title>
    <script src="../../scripts/jquery.min.js"></script>    
    <script src="../../scripts/Chart.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <style>
         div{
            /* align: center; */
            margin-top: 1%;
            margin-left: 5%;
        }
        button{
            margin-top: 2%;
            margin-left: 70%;
            background: #87CEEB;
            /* decoration: none; */
        }
        .something select{
            padding: 7px;
            font-size: 15px;
            margin: 0px 1px;
        }
        .something input{
            padding: 7px;
            font-size: 15px;
            margin: 0px 1px;
        }
        .something input:hover{
            background-color: black;
            color: white;
            cursor: pointer;
        }
        
    </style>
</head>
<body>
    

    <div style="width: 50% ">
        <div align="center" class="something" >
            <form action="departmentWiseStudentEnrollment.php" method="POST">
            <select id="course_dropDown" name="select">
                <option selected disabled> <i>Chart List </i></option>
                <option value="LineChart"> LineChart</option>
                <option value="PieChart"> PieChart</option>
                <option value="BarChart"> BarChart</option>
            </select>
            
            <input type="submit" name="submit" onclick="drawChart()"> 
            </form>
            <div id="chart_div" align="center"></div>
        </div>
        <?php
            $structure = isset($_POST['select']) ? $_POST['select'] : "BarChart";
        ?>
        

    </div>
    <button><a href="dashboard_Head.php">Back</a></button>
    
</body>
</html>


<?php
    $ycpArr = array();
    $ycpArr1 = array();
    $i=0;
    $q = "SELECT d.deptShortName AS School , COUNT(s.studentID) AS total 
            FROM  department AS d
            LEFT JOIN  program AS p
            ON d.deptShortName = p.deptShortName 
            LEFT JOIN student AS s
            ON s.programID = p.programID 
            GROUP BY d.deptShortName";

    $query = mysqli_query($con, $q);
    while($travese = $query->fetch_assoc()){
        $ycpArr[$i][0]=$travese['School'];
        $ycpArr[$i][1]=$travese['total'];
        $i++;
    }

?>
<script>
    var obj = <?php echo json_encode($ycpArr); ?>;
</script>

<script type="text/javascript">
    var obj = <?php echo json_encode($ycpArr); ?>;
      google.charts.load('current', {'packages':['corechart']});

      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Student');
        data.addColumn('number', 'Enrollment');
        for(i = 0; i < obj.length; i++)
            data.addRow([obj[i][0],parseInt(obj[i][1])]);
        // Set chart options
        var options = {'title':'Department Wise Student Enrollment  ',
                       'width':600,
                       'height':500,
			   is3D:true,};


        var chart = new google.visualization.<?php echo $structure ;?>
        (document.getElementById('chart_div'));
        chart.draw(data, options);
      }
	
</script>
