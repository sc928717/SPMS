<?php
include '../../connection.php';
$sem = $_SESSION['semester'];
$y = $_SESSION['year'];
$id = $_SESSION['id'];
$e = $_POST['e'];
$registeredCourses = $_POST['registeredCourses'];
$enrollmentID = $_POST['enrollmentID'];
for ($y = 0; $y < $e; $y++) {
    for ($y1 = 0; $y1 < count($registeredCourses); $y1++) {
        if ($registeredCourses[$y1] == $enrollmentID[$y]) {
            
            $insert = "INSERT INTO registration(studentID, enrollmentID) VALUES ('$id', '$enrollmentID[$y]')";
            mysqli_query($con, $insert);
            $insert = "UPDATE section SET totalNumberOfStudent = totalNumberOfStudent+1 WHERE enrollmentID='$enrollmentID[$y]'";
            mysqli_query($con,$insert);
            break;
        }
    }
}

?>
<script>
        alert("Successfully Done....!!!");
        window.location = 'dashboard_Student.php';
    </script>