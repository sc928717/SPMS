<?php
include '../../connection.php';
$sem = $_SESSION['semester'];
$y = $_SESSION['year'];
$id = $_SESSION['id'];


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IRAS-PLO</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <!-- <link rel="stylesheet" href="../../css/bootstrap.min.css"> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="studentStyle.css">
    <link rel="shortcut icon" type="image/x-icon" href="../../images/logo1.png">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script> -->
    <!-- <script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script> -->


    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <script src="../../scripts/repeater.js"></script>


</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">
        <a class="navbar-brand" href="#">Home</a>

        <div class="dropDownWrapper">
            <select id="graph" class="form-select">
                <option selected disabled> <i>Select Options </i></option>
                <option value="registration"> Course Registration </option>
                <option value="courseInformation"> Course Information </option>
                <option value="examination"> Examination </option>
            </select>
        </div> &nbsp



        <p>&nbsp&nbsp&nbsp</p>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <p align="right"> <?php echo $_SESSION['name']; ?> <br> Independent University, Bangladesh </p>
                <div class="navbar-text ml-lg-3">
                    <a href="../../index.php" class="btn btn-primary text-white shadow">Sign out</a>
                </div>
            </ul>
        </div>
    </nav>

    <!-- <button onclick="counterIncrement()">This is for test</button> -->
    <div class="graphContainer">
        <div id="registration" class="data content1" style="position: relative; padding: 2%;">
            <?php
            $q = "SELECT status FROM activeness WHERE name = 'registration'";
            $query = mysqli_query($con, $q);
            $t = $query->fetch_assoc();
            $abc = $sem . "_" . $y;
            $qq = "SELECT * FROM registration WHERE enrollmentID LIKE '%$abc%' AND studentID = '$id'";
            $query1 = mysqli_query($con, $qq);
            $t1 = $query1->fetch_assoc();

            if ($t['status'] == 'true' && $t1 == null) {
            ?>
                <form action="courseRegistration.php" method="POST">
                    <p><strong><i>You are going to register for <?php echo $sem . " " . $y; ?>:</i></strong></p>
                    <table class="table table-bordered">
                        <thead class="thead-light">
                            <tr>
                                <th>Select Course</th>
                                <th>Enrollment ID</th>
                                <th>Course ID</th>
                                <th>Section</th>
                                <th>Total enrollment</th>
                                <th>Enrolled Number</th>
                                <th>Day</th>
                                <th>Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $q = "SELECT * FROM section WHERE semester = '$sem' AND year = '$y'";
                            $query = mysqli_query($con, $q);
                            $i = 0;
                            while ($t = $query->fetch_assoc()) {
                                echo '<td><input type="checkbox" name = "registeredCourses[]" value = ' . $t['enrollmentID'] . ' style = "width: 3vh; height: 3vh;"></td>
                        <input type="hidden" name = "enrollmentID[]" value=' . $t['enrollmentID'] . '>
                        <td>' . $t['enrollmentID'] . '</td>
                        <td>' . $t['courseID'] . '</td>
                        <td>' . $t['sectionID'] . '</td>
                        <td>' . $t['totalEnrollment'] . '</td>
                        <td>' . $t['totalNumberOfStudent'] . '</td>
                        <td>' . $t['day'] . '</td>
                        <td>' . $t['classTime'] . '</td>
                        </tr>';
                                $i++;
                            }
                            echo '<input type="hidden" name="e" value = ' . $i . '>';
                            ?>
                        </tbody>
                    </table>
                    <div align="right">
                        <input type="submit" style="width: 10%;" name="insert" class="btn btn-primary text-white shadow" value="Register" />
                    </div>
                </form>
            <?php
            } else {
                echo '<h3 align="center"> Registration Is currently Unabailable. </h3>';
            }
            ?>

        </div>
        <div id="courseInformation" class="data content1" style="position: relative; padding: 1%;">
            <p align="center"><strong><i>Marks of all terms that are taken for all the registered courses for this semester:</i></strong></p>
            <table class="table table-bordered">
                <thead class="thead-light">
                    <tr>
                        <th>Course ID</th>
                        <th>Section</th>
                        <th>Quizes</th>
                        <th>Mid Term</th>
                        <th>Final Term</th>
                        <th>Project</th>
                        <th>Total Marks(100%)</th>
                        <th>Grade</th>

                    </tr>
                </thead>
                <tbody>
                    <?php
                    $q = "SELECT s.sectionID AS sec, s.courseID AS cou, s.enrollmentID as enr FROM registration AS r, section AS s
                                    WHERE r.studentID = '$id' AND r.enrollmentID = s.enrollmentID";
                    $query = mysqli_query($con, $q);
                    while ($t = $query->fetch_assoc()) {
                        $sec = $t['sec'];
                        $course = $t['cou'];
                        $enr = $t['enr'];
                        $mid;
                        $project;
                        $projectt;
                        $quiz;
                        $final;
                        $midt;
                        $quizt;
                        $finalt;
                    ?>
                        <tr>
                            <td><?php echo $sec; ?></td>
                            <td><?php echo $course; ?></td>
                            <td>
                                <?php
                                $qqq = "SELECT SUM(obatinMarks) as mark, SUM(mark) as m FROM evaluation AS e, question AS q, assessment AS a
                                    WHERE e.evaluationID LIKE '$id%'AND a.enrollmentID = '$enr' AND e.quesID = q.quesID AND q.assessmentID = a.assessmentID AND a.nameOfAss = 'Quiz'  AND e.obatinMarks != '-9999' GROUP BY q.assessmentID";
                                $qqq = mysqli_query($con, $qqq);
                                $qqq = $qqq->fetch_assoc();
                                $quiz = isset($qqq['mark']) ? $qqq['mark'] : 0;
                                $quizt = isset($qqq['m']) ? $qqq['m'] : 0;
                                echo $quiz;
                                ?>
                            </td>
                            <td><?php
                                $qqq = "SELECT SUM(obatinMarks) as mark , SUM(mark) as m FROM evaluation AS e, question AS q, assessment AS a
                                    WHERE e.evaluationID LIKE '$id%' AND e.quesID = q.quesID AND q.assessmentID = a.assessmentID AND a.nameOfAss = 'Mid'  AND e.obatinMarks != '-9999' GROUP BY q.assessmentID";
                                $qqq = mysqli_query($con, $qqq);
                                $qqq = $qqq->fetch_assoc();

                                $mid = isset($qqq['mark']) ? $qqq['mark'] : 0;
                                $midt = isset($qqq['m']) ? $qqq['m'] : 0;
                                echo $mid;
                                ?></td>
                            <td><?php
                                $qqq = "SELECT SUM(obatinMarks) as mark , SUM(mark) as m FROM evaluation AS e, question AS q, assessment AS a
                                    WHERE e.evaluationID LIKE '$id%' AND e.quesID = q.quesID AND q.assessmentID = a.assessmentID AND a.nameOfAss = 'Final'  AND e.obatinMarks != '-9999' GROUP BY q.assessmentID";
                                $qqq = mysqli_query($con, $qqq);
                                $qqq = $qqq->fetch_assoc();
                                $final = isset($qqq['mark']) ? $qqq['mark'] : 0;
                                $finalt = isset($qqq['m']) ? $qqq['m'] : 0;
                                echo $final;
                                ?></td>
                            <td>
                                <?php $qqq = "SELECT SUM(obatinMarks) as mark , SUM(mark) as m FROM evaluation AS e, question AS q, assessment AS a
                                    WHERE e.evaluationID LIKE '$id%' AND e.quesID = q.quesID AND q.assessmentID = a.assessmentID AND a.nameOfAss = 'Project'  AND e.obatinMarks != '-9999' GROUP BY q.assessmentID";
                                $qqq = mysqli_query($con, $qqq);
                                $qqq = $qqq->fetch_assoc();
                                $project = isset($qqq['mark']) ? $qqq['mark'] : 0;
                                $projectt = isset($qqq['m']) ? $qqq['m'] : 0;
                                echo $project;

                                ?></td>
                            <td> 
                            <?php 
                            $t = (($mid * 30 + $quiz * 20 + $final * 30  + $project * 20) / ($quizt + $midt + $finalt + $projectt));
                                    echo $t; 
                                    $quee = "UPDATE registration
                                    SET totalMakrs = '$t'
                                    WHERE studentID = '$id' AND enrollmentID = '$enr'";
                                    mysqli_query($con,$quee);
                                    ?></td>
                            <td>have to work</td>

                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <div id="examination" class="data">
            <br>
            <div class="wrapper">
                <?php

                // $q1 = "SELECT DISTINCT studentID FROM evaluation AS e WHERE e.studentID = '$id' ";
                // $query1 = mysqli_query($con, $q1);
                // if($query1->fetch_assoc() != null){
                //     $q = "SELECT * FROM assessment AS a, registration AS r WHERE r.studentID = '$id' AND a.enrollmentID = r.enrollmentID AND a.assessmentID != (SELECT DISTINCT q.assessmentID FROM question AS q, evaluation AS e WHERE q.quesID = e.quesID AND e.studentID = '$id')";
                // } else {
                $q = "SELECT * FROM assessment AS a, registration AS r WHERE r.studentID = '$id' AND a.enrollmentID = r.enrollmentID";
                // }
                $query = mysqli_query($con, $q);
                $i = 0;
                while ($t = $query->fetch_assoc()) {
                    $ass = $t['assessmentID'];
                    $q1 = "SELECT * FROM assessment AS a, registration AS r, evaluation AS e, question AS q WHERE a.assessmentID = '$ass'  AND q.assessmentID = a.assessmentID AND e.quesID = q.quesID AND e.studentID = '$id'";
                    $query1 = mysqli_query($con, $q1);
                    if ($query1->fetch_assoc() == null) {
                        echo "<form  method=\"POST\" action=\"giveExam.php\">
                    <input type=\"hidden\" name=\"assessmentID\" value = " . $t['assessmentID'] . "> 
                    <a href = \"#\" onclick=\"document.forms[" . $i . "].submit();\" style = \"text-decoration: none;\">
                    <div class=\"loadExam\">
                        <p>Exam type: " . $t['nameOfAss'] . "</p>
                        <p>Course ID: " . $t['enrollmentID'] . "</p>
                        <p>Exam Time: " . $t['time'] . " |" . $t['date'] . "</p>

                        </div>
                        </a>
                        </form>";
                        $i++;
                    }
                }
                ?>
            </div>

        </div>

    </div>

    <script src="../../scripts/jquery.min.js"></script>
    <script src="../../scripts/Chart.js"></script>
    <script>
        $(document).ready(function() {
            $("#graph").on(' change', function() {
                $(".data").hide();
                $("#" + $(this).val()).fadeIn(700);
            }).change();
        });
    </script>
</body>

</html>