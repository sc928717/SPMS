<?php
include '../../connection.php';
$sem = $_SESSION['semester']; // current semester
$y = $_SESSION['year']; // current year
$id = $_SESSION['id']; //student id



$file = isset($_POST['myfile']) ? $_POST['myfile'] : null;
$quesID = isset($_POST['quesID']) ? $_POST['quesID'] : null;
$enrollmentID = isset($_POST['enrollmentID']) ? $_POST['enrollmentID'] : null;
$evaluationID;
for ($i = 0; $i < count($file); $i++) {
    echo $i + 1 . " File Name<b>::</b> " . $file[$i] . " "; // this is per question answer
    echo "Question ID " . $quesID[$i] . " "; // this is question id
    $evaluationID = $id . "_" . $quesID[$i];  // evaluation id set up
    echo $evaluationID . "<br>";
    $q= "INSERT INTO evaluation (evaluationID, studentAns,enrollmentID,quesID,studentID,obatinMarks) 
        VALUES ('$evaluationID', '$file[$i]', '$enrollmentID', '$quesID[$i]','$id', '-9999')";
    mysqli_query($con,$q);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IRAS-PLO</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="studentStyle.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>



    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <script src="../../scripts/jquery.min.js"></script>
    <script src="../../scripts/Chart.js"></script>


</head>

<body>

    <h1>Submission Confirmation</h1>

</body>

</html>

<script>
        alert("Successfully Done....!!!");
        window.location = 'dashboard_Student.php';
    </script>